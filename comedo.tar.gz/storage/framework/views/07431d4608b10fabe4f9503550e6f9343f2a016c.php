<?php $__env->startSection('content'); ?>
	<h2>Estdos Semanal</h2>
	

	<div>
		<table class="table">
			<tr>
				<?php foreach($estados->estadosDias() as $key => $value): ?>
					<td style=" text-align: center; ">
						<?php echo e(Form::open(array('url' =>"$user->id/estados/$estados->id/updateEstadoSemanal"))); ?>

						<?php echo e(Form::hidden('id',$estados->id)); ?>

						<?php echo e(Form::hidden('dia',$key)); ?>

						<h4><?php echo e($key); ?></h4>
						<?php if($value==0): ?>
							<?php echo e(Form::hidden('estado','1')); ?>

							<img src="<?php echo e(asset('/img/no_comida.png')); ?>" alt="No Anotado">
						<?php else: ?>
							<?php echo e(Form::hidden('estado','0')); ?>

							<img src="<?php echo e(asset('/img/si_comida.png')); ?>" alt="Si Anotado">
						<?php endif; ?>
						<?php echo e(Form::submit('Modificar',array('class'=> 'btn btn-primary'))); ?>

						<?php echo e(Form::token()); ?>

						<?php echo e(Form::close()); ?>

					</td>
				<?php endforeach; ?>
			</tr>
		</table>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script type="text/javascript">
		
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>