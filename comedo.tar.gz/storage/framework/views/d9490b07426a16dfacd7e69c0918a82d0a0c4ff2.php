<?php $__env->startSection('content'); ?>
    <h2>Faltas</h2>
    <table class="table table-striped table-bordered">
        <thead>
            <th>Fechas</th>
        </thead>
        <tbody>
            <?php foreach($faltas as $falta): ?>
            <tr>
                <td>
                <?php echo e($falta->fecha); ?>

                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>