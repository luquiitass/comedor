<?php $__env->startSection('content'); ?>

<?php echo $__env->make('mensajes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<h2>Registrar usuario</h2>
<?php echo e(Form::open(array('route' => 'user.store','class' => 'form'))); ?>


	<div class="form-group">
		<?php echo e(Form::label('legajo')); ?>

		<?php echo e(Form::text('legajo' ,null , array('class' =>  'form-control'))); ?>

	</div>
	<div class="form-group">
		<?php echo e(Form::label('email')); ?>

		<?php echo e(Form::text('email' ,null , array('class' =>  'form-control'))); ?>

	</div>
	<div class="form-group">
		<?php echo e(Form::label('nombre' )); ?>

		<?php echo e(Form::text('nombre',null, array('class' =>'form-control'))); ?>

	</div>
	<div class="form-group">
		<?php echo e(Form::label('apellido')); ?>

		<?php echo e(Form::text('apellido',null, array('class' => 'form-control'))); ?>

	</div>
	<div class="form-group">
		<?php echo e(Form::label('dni')); ?>

		<?php echo e(Form::text('dni',null, array('class' => 'form-control'))); ?>

	</div>
	<div class="form-group">
		<?php echo e(Form::label('telefono')); ?>

		<?php echo e(Form::text('telefono',null, array('class' => 'form-control'))); ?>

	</div>
	<?php echo e(Form::token()); ?>

	<?php echo e(Form::submit(null,array('class' => 'btn btn-success'))); ?>

<?php echo e(Form::close()); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>