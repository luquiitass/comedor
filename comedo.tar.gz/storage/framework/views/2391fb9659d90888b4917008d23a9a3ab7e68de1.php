<?php $__env->startSection('content'); ?>

<h2>Login</h2>

<?php echo $__env->make('mensajes.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo e(Form::open(array('route' => 'handleLogin'))); ?>

	<div class="form-group">
		<?php echo e(Form::label('email')); ?>

		<?php echo e(Form::text('email' ,null , array('class' =>  'form-control'))); ?>

	</div>

	<div class="form-group">
		<?php echo e(Form::label('password')); ?>

		<?php echo e(Form::text('password' ,null , array('class' =>  'form-control'))); ?>

	</div>

	<div class="form-group">
		<?php echo e(Form::token()); ?>

		<?php echo e(Form::submit('Entrar' , array('class' =>  'btn btn-success'))); ?>

	</div>
<?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>