<head>
	<meta charset="UTF-8">
	<title> @yield('titulo','Titulo no definido pap')</title>

	<link rel="stylesheet" type="text/css" href="/css/estilos.css">
	
    <link href="/css/bootstrap.css" rel="stylesheet">

    <link rel="shortcut icon" href="../favicon.ico" type="image/x-icon">
    <link rel="icon" href="../icono.ico" type="image/x-icon">

    <script src="/js/jquery.js"></script>
    <script src="/js/myjava.js"></script>
    <script src="/js/bootstrap.js"></script>
    <script>window.jQuery || document.write('<script src="../js/jquery.min.js"><\/script>')</script>

	
</head>