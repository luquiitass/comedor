<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Class AnuncioController
 *
 * @author  The scaffold-interface created at 2016-07-06 05:12:50pm
 * @link  https://github.com/amranidev/scaffold-interface
 */
class Anuncio extends Model
{
    public $timestamps = false;

    protected $table = 'anuncios';

	
}
