<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Estado_usuarioController
 *
 * @author  The scaffold-interface created at 2016-07-07 04:53:14pm
 * @link  https://github.com/amranidev/scaffold-interface
 */
class Estado_usuario extends Model
{
    public $timestamps = false;

    protected $table = 'estado_usuarios';

	
}
